function [R] = RGB(v,N)
R1=0; %R2=0;


for i=1:size(N{v},2)
    R1=R1+1/size(N{N{v}(1,i)},2);
    a=N{N{v}(1,i)}(1,:);
    a=a(a~=v);
%     for j=1:size(a,2)
%         R2=R2+1/size(N{a(1,j)},2);
%     end
end


% len1=size(N{v},2);
% for i=1:size(N{v},2)
%     a=N{N{v}(1,i)};
%     R1=R1+1/size(a,2);
%     a=a(a~=v);
%     for j=1:size(a,2)
%         R2=R2+1/size(N{a(1,j)},2);
%     end
% end



R=R1;
  
end

