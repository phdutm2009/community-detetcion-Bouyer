function [x]=PreferentialAttachmentIndex(Adj,i,j)
x=(size(Adj{i},2)*size(Adj{j},2));
end