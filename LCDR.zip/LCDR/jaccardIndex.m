function [x]=jaccardIndex(Adj,i,j)
x=numel(intersect(Adj{i}(1,:),Adj{j}(1,:)))/numel(union(Adj{i}(1,:),Adj{j}(1,:)));
end