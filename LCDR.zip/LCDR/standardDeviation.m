function [sigma]=standardDeviation(X,P,mu)
sigma=0;
for i=1:length(X)
    sigma=sigma+((X(i)^2)*P(i));
end
sigma=sigma-mu^2;
sigma=sqrt(sigma);
end