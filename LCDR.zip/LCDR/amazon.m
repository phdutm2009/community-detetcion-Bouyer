close all; clear all; clc;fclose all;warning off;
load('com-Amazon.mat');% loading dataset
En=Problem.A ;%consists of Adjecency matrix
N=[]; % Neighbors list N(i) : Neighbors of node i
% for i=1:size(En,1)
%     N=[N nghbors(i,En)];
% end

for e=1:0.2:1
    [V1,cN]=malgorithm(En,Problem.A,e);
    disp(strcat('Modularity:',num2str(QFModul(V1,En))))
    %disp(strcat('Number of communities:',num2str(cN),'/',num2str(communityCount)))
    %disp(strcat('NMI:',num2str(PSNMI(V1,GT))))
    disp('****************************************************')
end
% writeGraph(En,V1,cN,'test.dot');
% system('fdp -Tpng test.dot -o test.png');
% figure;
% imshow(imread('test.png'))
% title('Proposed method')
% disp(strcat('Modularity:',num2str(QFModul(V1,En))))
% disp(strcat('Number of communities:',num2str(cN)))
% disp(strcat('NMI:',num2str(PSNMI(V1,GT))))