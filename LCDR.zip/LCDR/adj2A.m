function [A]=adj2A(Adj)
A=sparse(length(Adj),length(Adj));
for i=1:length(Adj)
    a=Adj{i};
    for j=1:size(a,2)        
        A(i,a(1,j))=a(2,j);
    end
end
end