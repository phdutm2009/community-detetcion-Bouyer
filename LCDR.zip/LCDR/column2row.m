function [Adj]=column2row(Adj)
for i=1:size(Adj,2)
    if(iscolumn(Adj{i}))
        Adj{i}=Adj{i}';
    end
end
end