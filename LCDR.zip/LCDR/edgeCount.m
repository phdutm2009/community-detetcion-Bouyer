function [out]=edgeCount(CM_n,Nodes)
out=0;
for node=Nodes
    [pos,f]=binSearch(CM_n(1,:),1,length(CM_n(1,:)),node);
    if(f)
        out=out+CM_n(2,pos);
    end
end
end