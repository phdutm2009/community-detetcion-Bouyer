% close all; clear all; clc;fclose all;warning off;
tic
load('dolphins2.mat');% loading dataset
disp('dolphins2.mat');% loading dataset

for e=1:0.01:1
    [V1,cN]=malgorithm(Problem.A,Adj,e);
    disp(strcat('Modularity:',num2str(QFModul(V1,Problem.A))))
    disp(strcat('NMI:',num2str(PSNMI(V1,GT))))
    disp(strcat('Number of communities:',num2str(cN)))
    disp('****************************************************')
end
toc