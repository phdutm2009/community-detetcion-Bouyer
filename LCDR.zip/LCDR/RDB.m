function [R]=RDB(v,N)
R=0;

for i=1:size(N{v},2)
    R=R+1/size(N{N{v}(1,i)},2);
end
end