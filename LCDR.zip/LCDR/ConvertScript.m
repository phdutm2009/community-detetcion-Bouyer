load('astro-ph.mat')

Adj=mat2adjList(Problem.A);

save('astro-ph.mat','Adj','-append')