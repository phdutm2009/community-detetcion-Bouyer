function [V1,CM,cN]=mergeCommunitiesByEdgeCount(Adj,CM)
cN=size(CM,2);
while(true)
    V1=zeros(1,size(Adj,2));
    for i=1:cN
        V1(CM{i}{1})=i;
        V1(CM{i}{2})=i;
    end
% % %     disp(num2str(find(V1==0)))
    preCount=cN;
% % % %     disp(['***********************community count: ' num2str(preCount)])
    delList=[];
    [delList,V2]=merge2(CM,V1,Adj);
    
    
    for d_=delList
        CM{V2(d_)}{1}=union(CM{V2(d_)}{1},CM{d_}{1});
        CM{V2(d_)}{2}=union(CM{V2(d_)}{2},CM{d_}{2});
        
        
        for n_ind=1:size(CM{d_}{3},2)
            [pos,f]=binSearch(CM{V2(d_)}{3}(1,:),1,size(CM{V2(d_)}{3}(1,:),2),CM{d_}{3}(1,n_ind));
            if(f)
                CM{V2(d_)}{3}(2,pos)=CM{V2(d_)}{3}(2,pos)+CM{d_}{3}(2,n_ind);
            else
                if(CM{d_}{3}(1,n_ind)>CM{V2(d_)}{3}(1,pos))
                    CM{V2(d_)}{3}=[CM{V2(d_)}{3}(:,1:pos) CM{d_}{3}(:,n_ind) CM{V2(d_)}{3}(:,(pos+1):end)];
                else
                    CM{V2(d_)}{3}=[CM{V2(d_)}{3}(:,1:(pos-1)) CM{d_}{3}(:,n_ind) CM{V2(d_)}{3}(:,pos:end)];
                end
            end
        end
    end
    CM(delList)=[];
    cN=size(CM,2);
% % %     disp(['***********************community count: ' num2str(cN)])
    if(preCount==cN)
        break;
    end
end

end

function [delList,V3,CM2]=merge2(CM,V1,Adj)
V3=1:size(CM,2);
CM2=cell(1,size(CM,2));
for i=1:size(CM,2)
    CM2{i}=i;
end
delList=[];
for i=1:size(CM,2)
    vTmp=sparse(zeros(1,size(CM,2)));
    maxInd=[];
    maxV=0;
    for j=1:size(CM{i}{3},2)
        vTmp(V1(CM{i}{3}(1,j)))=vTmp(V1(CM{i}{3}(1,j)))+CM{i}{3}(2,j);
        if(V1(CM{i}{3}(1,j))~=i)
            if(vTmp(V1(CM{i}{3}(1,j)))>=maxV)
                if(vTmp(V1(CM{i}{3}(1,j)))>maxV)
                    maxInd=[];
                end
                maxInd=[maxInd V1(CM{i}{3}(1,j))];
                maxV=vTmp(V1(CM{i}{3}(1,j)));
            end
        end
    end      
    self=vTmp(i);
    if(3.75*maxV>=self && maxV~=0)
        maxInd=maxInd(1);
        if(V3(i)<V3(maxInd))
% % % %             disp(['community #' num2str(V3(maxInd))  '=> #' num2str(V3(i))])
            delList=[delList V3(maxInd)];
            CM2{V3(i)}=union(CM2{V3(i)},CM2{V3(maxInd)});
            V3(CM2{V3(i)})=V3(i);
        elseif(V3(i)>V3(maxInd))
% % % %             disp(['*community #' num2str(V3(i))  '=> #' num2str(V3(maxInd))])
            delList=[delList V3(i)];
            CM2{V3(maxInd)}=union(CM2{V3(i)},CM2{V3(maxInd)});
            V3(CM2{V3(maxInd)})=V3(maxInd);
%         else
% % % %             disp(['no merge :' num2str(i)])
        end
%     else
% % % %         disp(['no merge :' num2str(i)])
    end
end
end