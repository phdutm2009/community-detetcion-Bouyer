function [out]=exclude(A,a)
out=[];
for i=A
    found=false;
    for j=a
        if(i==j)
            found=true;
        end
    end
    if(~found)
        out=[out i];
    end
end