function [x]=saltonIndex(Adj,i,j)
x=(numel(mutualKnownNeighbors(Adj,i,j))/sqrt(size(Adj{i},2)*size(Adj{j},2)));
end