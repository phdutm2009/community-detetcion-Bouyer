function [mu,MUs]=ExpectedValue(X,P)
mu=0;
MUs=[];
for i=1:length(P)
    MUs=[MUs X(i)*P(i)];
    mu=mu+MUs(i);
end
end