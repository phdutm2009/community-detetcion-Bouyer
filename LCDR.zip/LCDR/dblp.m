%close all; clear all; clc;fclose all;warning off;
tic
load('dblp.mat');% loading dataset
disp('com-DBLP.mat');% loading dataset

for e=1:0.01:1
    [V1,cN]=malgorithm(A,Adj,e);
    toc
    disp(strcat('Modularity:',num2str(QFModul(V1,A))))
    disp(strcat('Number of communities:',num2str(cN)))
    disp(strcat('NMI:',num2str(computeNMI(GT,V1))))
%            [nmi]=computeNMI(GT,V)
    toc
    disp('****************************************************')
    
end
