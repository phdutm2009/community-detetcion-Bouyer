function [out,f]=binSearch(A,sInd,eInd,x)

f = 0;
while sInd <= eInd
    mid = ceil((sInd + eInd) / 2);
    out=mid;
    if A(mid) == x
        out = mid;
        f = 1;
        break;
    else if A(mid) > x
            eInd = mid - 1;
        else
            sInd = mid + 1;
        end
    end
end
% if f == 0;
%     out = -1;
% end
end



% out=((sInd+eInd)/2);
% if(A(round(out))==x)
%     f=true;
%     out=round(out);
%     return
% end
% if(sInd==eInd)
%     f=false;
%     out=round(out);
%     return;
% end
% if(A(round(out))>x)
%     [out,f]=binSearch(A,sInd,floor(out),x);
%     return;
% elseif(A(round(out))<x)
%     [out,f]=binSearch(A,ceil(out),eInd,x);
%     return;
% else
% end
% end