function [MN]=mutualKnownNeighbors(N,v,u)
NU=N{u}(1,:);
NV=N{v}(1,:);

MN=intersect(NU,NV);
end