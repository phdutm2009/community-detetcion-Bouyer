function [x]=commonNeighbors(Adj,i,j)
x=numel(mutualKnownNeighbors(Adj,i,j));
end