function [R]=adamicAdar(Adj,i,j)
MKN=mutualKnownNeighbors(Adj,i,j);
R=0;
for i=1:length(MKN)
    num=size(Adj{MKN(i)},2);
    R=R+1/(log(num));
end

end