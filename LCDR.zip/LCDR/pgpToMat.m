clear all
fid = fopen('colleb_ 2003_up.csv');
out = textscan(fid,'%s%s%s%s%s%s%s','delimiter',',');
fclose(fid);
En=sparse(31163,31163);
S=out{1,1};
T=out{1,2};
for i=2:length(T)
    disp(i)
   En(str2num(S{i,1})+1,str2num(T{i,1})+1)=1;
   En(str2num(T{i,1})+1,str2num(S{i,1})+1)=1;
end
