function [En,GT]=LFRgenerator(nodeN,avgDeg,maxDeg,expND,expCS,mixParam,cMin,cMax)
delete('parameters.dat')
fid = fopen('parameters.dat','w');
fprintf(fid,[num2str(nodeN),'\n']);
fprintf(fid,[num2str(avgDeg),'\n']);
fprintf(fid,[num2str(maxDeg),'\n']);
fprintf(fid,[num2str(expND),'\n']);
fprintf(fid,[num2str(expCS),'\n']);
fprintf(fid,[num2str(mixParam),'\n']);
fprintf(fid,[num2str(cMin),'\n']);
fprintf(fid,num2str(cMax));
fclose(fid);
%************************************
system('benchmark -sup');
%************************************
fid = fopen('network.dat');
En=zeros(nodeN,nodeN);
tline = fgetl(fid);
while ischar(tline)    
    try
        a=str2num(tline);
        
        En(a(1),a(2))=1;
        En(a(2),a(1))=1;        
    catch
    end
    tline = fgetl(fid);
end
fclose(fid);
%************************************
fid = fopen('community.dat');
GT=zeros(1,nodeN);
tline = fgetl(fid);
while ischar(tline)
    try
        a=str2num(tline);
        GT(a(1))=a(2);
    catch
    end
    tline = fgetl(fid);
    
end
fclose(fid);

disp(strcat('Modularity:',num2str(QFModul(GT,En))))
end