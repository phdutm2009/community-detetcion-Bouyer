function[V1,cN]=malgorithm(A,Adj,m)
n=size(Adj,2);
m=0;
R=zeros(n,3);
V1=zeros(1,n);
rdb_max=-inf;
rdb_min=+inf;
rdb_sum=0;
for i=1:n
    R(i,1)=RDB(i,Adj);
    R(i,2)=sum(Adj{i}(2,:));
end
disp(toc);
cN=0;
CM=[];
fCentroids=[];
for i=1:n
    if(R(i,1)+0.016>=1)
        cN=cN+1;
        V1(i)=cN;
        CM{cN}=cell(1,2);
        CM{cN}{1}=i;
        fCentroids=[fCentroids;[i,R(i,1),0]];
    end
end
%**********************************************************************
[~,index] = sortrows(fCentroids,2,'desc'); fCentroids = fCentroids(index(1:end),:,:);

delList=[];
maxCentralNodeCount=1;
for i=1:cN
    if(fCentroids(i,3)~=0)
        continue;
    end
    fCentroids(i,3)=1;
    [tmpA,tmpA_]=neighbor_Of_Centroids(Adj{fCentroids(i,1)},fCentroids(:,1));
    for j=1:length(tmpA)
        if(fCentroids(tmpA_(j),3)~=0)
            continue;
        end
        [tmpB,tmpB_]=neighbor_Of_Centroids(Adj{tmpA(j)},fCentroids(:,1));
        vz=zeros(1,length(tmpB));
        for k=1:length(tmpB)
            vz(k)=sorensenIndex(Adj,tmpA(j),tmpB(k));
        end
        [x,y]=max(vz);
        fCentroids(tmpA_(j),3)=1;
        if(V1(tmpA(j))~=V1(tmpB(y(1))))
            delList=[delList V1(tmpA(j))];
            CM{V1(tmpB(y(1)))}{1}=[CM{V1(tmpB(y(1)))}{1} CM{V1(tmpA(j))}{1}];
            if(maxCentralNodeCount<length(CM{V1(tmpB(y(1)))}{1}))
                maxCentralNodeCount=length(CM{V1(tmpB(y(1)))}{1});
            end
            V1(CM{V1(tmpA(j))}{1})=V1(tmpB(y(1)));         
        end
    end
end
fCentroids=fCentroids(:,1);
CM(delList)=[];
cN=cN-numel(delList);
% % % % % disp('-----------------')
for i=1:size(CM,2)
    V1(CM{i}{1})=i;
end
nN=[];
maxMemberNodeCount=0;
% **********************************************************
for i=1:maxCentralNodeCount
    for j=1:size(CM,2)
        if(length(CM{j}{1})>=i)
            nN=Adj{CM{j}{1}(i)}(1,:);
            for k=1:length(nN)
                xC=[];
                if(V1(nN(k))==0)
                    tN=Adj{nN(k)}(1,:);
                    xC=[HubDepressedIndex(Adj,nN(k),CM{j}{1}(i));j];
                    [tmpA,tmpA_]=neighbor_Of_Centroids(tN,fCentroids);
                    for tmpA_i=tmpA
                        if(V1(tmpA_i)~=j)
                            sim_=HubDepressedIndex(Adj,nN(k),tmpA_i);
                            if(xC(1)<sim_)
                                xC(1)=sim_; 
                                xC(2)=V1(tmpA_i);
                            elseif(xC(1)==sim_)
                                xC(1)=inf;
                                xC(2)=inf;
                            end
                        end
                    end
                    if(xC(1)~=inf)

                        V1(nN(k))=xC(2);
                        CM{xC(2)}{2}=[CM{xC(2)}{2},nN(k)];
                        if(maxMemberNodeCount<length(CM{xC(2)}{2}))
                            maxMemberNodeCount=length(CM{xC(2)}{2});
                        end
                    end
                end
            end
        end
    end
end
r=[];
for i=1:n
    if(V1(i)==0)
        r=[r i];
    end
end
% % % % % disp('-----------------')
change=true;
while(numel(r)~=0 && change)
    change=false;
    delList=[];
    for i=1:length(r)
        y=Adj{r(i)}(1,:);
        z=zeros(2,length(y));
        z(1,:)=y;
        z(2,:)=V1(y);
        if(~isempty(z))
            change=true;
            k=zeros(1,cN);
            for j=1:size(z,2)
                if(z(2,j)~=0)
                    k(z(2,j))=k(z(2,j))+R(z(1,j),1);
                end
            end
            [tmpx,tmpy]=max(k);
            tmpC=find(k==tmpx);
            if(numel(tmpC)>1)
                tmpk=zeros(2,length(tmpC));
                tmpk(1,:)=tmpC;
                for cc=1:length(tmpC)
                    for cmc=1:length(y)
                        if(V1(y(cmc))==tmpk(1,cc))
                            tmpk(2,cc)=tmpk(2,cc)+1;
                        end
                    end
                end
                [tmpx,tmpy]=max([tmpk(2,:)]);
                tmpy=tmpk(1,tmpy);
            end
            CM{tmpy}{2}=[CM{tmpy}{2},r(i)];
            V1(r(i))=tmpy;
            delList=[delList i];
        end
    end
    r(delList)=[];
end
% % % disp('-----------------')
for i=1:length(r)
    cN=cN+1;
    CM{cN}{1}=r(i);
    CM{cN}{2}=[];
    CM{cN}{3}=[];
    V1(r(i))=cN;
end
%***********************************************
for i=1:size(CM,2)
    tmpN=[]; 
    nodes_CM_i=union(CM{i}{1},CM{i}{2});
    if(iscolumn(nodes_CM_i))
        nodes_CM_i=nodes_CM_i';
    end
    for node_cm=nodes_CM_i
        for n_ind=1:size(Adj{node_cm}(1,:),2)
            if(isempty(tmpN))
                tmpN=Adj{node_cm}(:,n_ind);
                continue;
            end
            [pos,f]=binSearch(tmpN(1,:),1,size(tmpN,2),Adj{node_cm}(1,n_ind));
            if(f)
                tmpN(2,pos)=tmpN(2,pos)+Adj{node_cm}(2,n_ind);
            else
                if(Adj{node_cm}(1,n_ind)>tmpN(1,pos))
                    tmpN=[tmpN(:,1:pos) Adj{node_cm}(:,n_ind) tmpN(:,(pos+1):end)];
                else
                    tmpN=[tmpN(:,1:(pos-1)) Adj{node_cm}(:,n_ind) tmpN(:,pos:end)];
                end
            end
        end
    end
    CM{i}{3}=tmpN;
end
 [V1,CM,cN]=mergeCommunitiesByEdgeCount(Adj,CM);
for i=1:size(CM,2)
    V1(CM{i}{1})=i;
    V1(CM{i}{2})=i;
end
return;
end