function [Adj]=mat2adjList(A)
Adj=cell(1,size(A,2));
for i=1:size(A,2)
    [~,tmpy]=find(A(i,:)~=0);
    Adj{i}=[tmpy;full(A(i,tmpy))];
end

end