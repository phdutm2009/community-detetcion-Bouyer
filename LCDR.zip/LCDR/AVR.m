function [R1]=AVR(i,N)
R1=size(N{i},2);
end