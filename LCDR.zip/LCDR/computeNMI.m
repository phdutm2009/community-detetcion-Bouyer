function [nmi]=computeNMI(GT,V)
gt=[];
v=[];
for i=1:length(GT)
    if(GT(i)~=0)
       gt=[gt, GT(i)];
       v=[v, V(i)];
    end
end
gtUnique=unique(gt);
vUnique=unique(v);
for i=1:length(gtUnique)
    inds=find(gt==gtUnique(i));
    gt(inds)=i;
end
for i=1:length(vUnique)
    inds=find(v==vUnique(i));
    v(inds)=i;
end
nmi=PSNMI(gt,v);
end