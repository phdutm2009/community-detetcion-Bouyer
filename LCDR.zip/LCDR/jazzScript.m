tic
close all; clear all; clc;fclose all;warning off;
load('Jazz.mat');% loading dataset
disp('Jazz.mat');% loading dataset

%************************************************
for e=1:0.01:1
    [V1,cN]=malgorithm(Problem.A,Adj,e);
    disp(strcat('Modularity:',num2str(QFModul(V1,Problem.A))))
    disp(strcat('Number of communities:',num2str(cN)))
    disp('****************************************************')
    toc
end

