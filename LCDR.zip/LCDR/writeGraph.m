function []=writeGraph(En,label,cIndex,fname)
delete(fname)
V1=label;
colors=[]; % Random color holder
for i=1:cIndex
    colors=[colors;struct('C',sprintf('[shape=circle, style=filled, fillcolor="#%s%s%s%s%s%s"]\n',dec2hex(round(rand(1)*15)),dec2hex(round(rand(1)*15)),dec2hex(round(rand(1)*15)),dec2hex(round(rand(1)*15)),dec2hex(round(rand(1)*15)),dec2hex(round(rand(1)*15))))]; % Random color
end


[x,y]=find(triu(En)==1);
fid = fopen(fname, 'a');
fprintf(fid, 'digraph{\n');
fprintf(fid, ' edge [dir=none]\n');
for i=1:length(x)
    fprintf(fid, '    %s-> %s;\n', num2str(x(i)),num2str(y(i)));   
end
clear x y;
for i=1:length(label)
    if (label~=0)
        fprintf(fid, '%s', num2str(i));
        fprintf(fid,' ');
        b=label(i);
        fprintf(fid,colors(b).C);
    end
end
fprintf(fid, '}');
fclose(fid);
clear b
clear fid
end