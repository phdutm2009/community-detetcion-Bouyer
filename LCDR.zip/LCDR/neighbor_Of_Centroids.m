function [A,B]=neighbor_Of_Centroids(N,CA)
A=[];
B=[];
for k=1:size(N,2)
    x=find(CA==N(1,k), 1);
    if(~isempty(x))
        A=[A N(1,k)];
        B=[B x];
    end
end
end