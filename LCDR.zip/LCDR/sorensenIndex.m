function [x]=sorensenIndex(Adj,i,j)
x=2*(numel(mutualKnownNeighbors(Adj,i,j)))/(size(Adj{i},2)+size(Adj{j},2));
end
