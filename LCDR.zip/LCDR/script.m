clear all
close all
clc
load('youtube')
A=adj2A(Adj);

save('youtube')